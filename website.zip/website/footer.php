<footer>
    <div class="back-color">
        <ul class="nav">
            <li class="nav-list"><a href="#concept">concept</a></li>
            <li class="nav-list"><a href="#service">service</a></li>
            <li class="nav-list"><a href="#floor">floor</a></li>
            <li class="nav-list"><a href="#strong">strong</a></li>
            <li class="nav-list"><a href="#staff">staff</a></li>
            <li class="nav-list"><a href="#howUse">howUse</a></li>
            <li class="nav-list"><a href="#access">access</a></li>
            <li class="nav-list"><a href="#contact">contact</a></li>
        </ul>
    </div>

</footer>
<script src="<?php echo get_template_directory_uri(); ?>/dist/main.bundle.js"></script>
<?php wp_footer(); ?>